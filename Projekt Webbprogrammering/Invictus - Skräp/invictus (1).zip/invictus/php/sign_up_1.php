<?
	
	// Definera en funktion som sköter uppkoppling till databasen
	function connect_db() { 
	
		// Här ska du lägga in anslutningsinformation för att kunna ansluta dig mot din databas:
		// DittAnvändarID, DittLösen och den databas du har skapat tabellerna i.
	
	$mysqli = new mysqli('localhost', 'root', '', 'invictus');
	
		//Kontrollerar teckentabell
	if (!$mysqli->set_charset("utf8")) {
    	echo "Fel vid inställning av teckentabell utf8: %s\n". $mysqli->error;
	} else {
 		//echo "Nuvarande teckenkodningstabell: %s\n". $mysqli->character_set_name();
	}

	if ($mysqli->connect_errno) {
	    echo "Misslyckades att ansluta till MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	}

	return $mysqli;
}
	?>
	<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<title>Sign Up</title>	
        <link rel="stylesheet" href="../css/sign_up.css"/>
        <link rel="stylesheet" href="../css/header.css"/>
        <link rel="stylesheet" href="../css/footer.css"/>
	</head>
	<body>
	<header>
    
<div>
    <a href="index.php" ><img src="../images/logo.png"/></a>
    </div>
    
    <nav id="navigation" class="global-navigation" role="navigation">
    <ul class="global">
        <li class="huvudmeny"><a href="watches.php">Watches</a>
        <ul class="drop">
        <li class="submeny"><a href="classic.php">Classic Watches</a></li>
        <li class="submeny"><a href="exclusive.php">Exclusive Watches</a</li>
        <li class="submeny"><a href="sport.php">Sport Watches</a>           </li>
        </ul>
        </li>
    <li class="huvudmeny"><a href="our_story.php">Our story</a>         </li>
    <li class="huvudmeny"><a href="social_media.php">Social media</a></li>
    <li class="huvudmeny"><a href="contact_us.php">Contact us</a>       </li>
    <li class="huvudmeny"><a href="shopping_cart.php">Shopping cart</a></li>
    </ul>
</nav>
        
</header>
	<?php
	// Om användaren klickat på formulärets spara-knapp
	if(isset($_POST['spara'])){
	
		// Hämta in värden från formulär med hjälp av POST
		
		$Fnamn = $_POST['Fnamn'];
		$Enamn = $_POST['Enamn'];
		$Gatuadress = $_POST['Gatuadress'];
		$Postnummer = $_POST['Postnummer'];	
		$Postadress = $_POST['Postadress'];	
		$Telefon = $_POST['Telefon'];	
		$Epost = $_POST['Epost'];	
	
		// SQL-fråga (INSERT) 
		$sql = "INSERT INTO person (Fnamn,Enamn,Gatuadress,Postnummer,Postadress,Telefon,Epost) VALUES ('$Fnamn','$Enamn','$Gatuadress','$Postnummer','$Postadress','$Telefon','$Epost')";
	
		// Kör frågan
		if($mysqli = connect_db()) {
 	
		$mysqli->query($sql);
		print_r($mysqli->error);
		}
		// Skriv ut meddelande och länk tillbaka till startsidan
		echo "Personen är nu inlagd i databasen<br />";
		echo "<a href='person.php'>Tillbaka till listningssidan</a>";
	}

	// Om användare INTE klickat på spara-knapp
	else{

		
		
		?>
		
		<!-- Ett formulär med samtliga kolumner på den aktuella raden -->
		<!--  PersonId skickas med i querystring, detta görs i formulärets action-attribut -->
		<!-- I varje cell skrivs en kolumn ut, detta med hjälp av variabeln $myRow (arrayen som resultatet av SQL-frågan sparats i) -->
		
		<section>
    <div id="signup">
        
    <h2>Sign up</h2>
        
    <form action="sign_up.php" method="post">
    <p><label for="fornamn">First name: </label>
    <br>
    <input type="text" id="fornamn" name="fornamn" size="30" /></p>
    <p><label for="efternamn">Last name: </label>
    <br>
    <input type="text" id="efternamn" name="efternamn" size="30" /></p>
        
    <p><label for="email">E-mail: </label>
    <br>
    <input type="text" id="email" name="email" size="30" /></p>
    <p><label for="adress">Adress: </label>
    <br>
    <input type="text" id="adress" name="adress" size="30" /></p>
    
    <p><label for="postnummer">Postcode: </label>
    <br>
    <input type="text" id="postnummer" name="postnummer" size="30" /></p>
    <p><label for="stad">City: </label>
    <br>
    <input type="text" id="stad" name="stad" size="30" /></p>
        
    <p><label for="mobil">Phonenumber: </label>
    <br>
    <input type="text" id="mobil" name="mobil" size="30" /></p>
    <p><label for="password">Password: </label>
    <br>
    <input type="password" id="password" name="password" size="30" /></p>
    
    <p><input type="submit" id="signup" name="signup" value="Sign up" /></p>
    </form>
        
    </div>
</section>
		<?
		}
		?>
<footer>
    <div id="adress">
        Contact us
    <br>
    <br>
        Sturegatan 4
    <br>
        114 35 Stockholm
    <br>
        Sweden
    <br>
        <a href="mailto:invictuswatches@gmail.com">invictuswatches@gmail.com</a>
    <br>
        <a href="tel:+46 589-861-00">+46 589-861-00</a>
    </div>
    
    <div id="social">
        Social media
    <br>
    <br>
        <a href="https://www.instagram.com/invictuswatches/">
        <img src="../images/instagram.png" alt="instagram"/>
        </a>
        <a href="https://twitter.com/InvictusWatches">
        <img src="../images/twitter.png" alt="twitter" />     
        </a>
        <a href="https://www.facebook.com/invictuswatches/?notif_t=fbpage_fan_invite">
        <img src="../images/facebook.png" alt="facebook" />     
        </a>
    </div>
    
    <div id="account">
        Account
    <br>
    <br>
        <a href="log_in.html">Log in</a>
    <br>
        <a href="sign_up.html">Sign up</a>
    </div>
    
    <div id="payment">
        Payment methods
    <br>
    <br>
        <img src="../images/mastercard.png" alt="mc" />     
        <img src="../images/americanexpress.png" alt="amex" />     
        <img src="../images/visa.png" alt="visa" />     
        </div>
        </footer>
	</body>
</html>