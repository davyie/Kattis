<?php 
function story(){
return '<section>
    <div id="bild">
    <img src="../images/sentence.jpg"/>
    </div>
    <aside>
    <h2>Our story</h2>
    <p>Time is a interesting phenomenon, some people say time is absolute and some says it’s relative. We at Invictus don’t know what to believe but we do believe in quality, style and that in whatever way you choose to spend your time, you should look amazing in keeping track of it.
    </p>
        
<p>We are five driven guys from Stockholm that lives for making a difference in people’s lives. Together we came up with and created Invictus watches, a exclusive luxury brand which is all about quality, style and service. Our handmade watches are built here in Stockholm with true quality parts and put together by the best in the business. it’s stylish design combined with elegant details gives you a accessory to trust and wear with confidence. Every model is produced in a limited amount of units, which makes every watch unique.
Our story is only the beginning, how you spend your time is the real story.
<br>
<br>
- We are Invictus
    </p>
    </aside>
    
    <aritcle id="founders">
    
    <h2>Founders</h2>
    
    <div>
        <h4>CEO - Jesper Eriksson</h4>
        <img src="../images/kevin.jpg" alt="Kevin" /><br>
<span>Invictus CEO Jesper Eriksson is the man controlling the company and it’s progress. You can find Jesper strolling the office with a smile on his face, mingling with the staff and hitting on the assistants. Jesper has a crucial role at Invictus and his speciality is brainstorming where he just throws ideas into the open, and other people write them down for him.
</span>
    </div>
        
    <div>
        <h4>Cheif Information Officer - Gagan Gurminder</h4>
        <img src="../images/kevin.jpg" alt="Kevin" /><br>
<span>Gagan Gurminder is the ”IT-Guru” of the office. Ironically he never seems to be at the office. Where is Gagan? - The most frequently asked question within the Invictus organization. Gagan is the Invictus meeting specialist and travels the world pitching Invictus to the market and discussing business collaboration across the globe with selected companies. If Gagan is not at the office in Stockholm, he probably discusses contracts in Zurich or Dubai.
</span>
    </div>
        
    <div>
        <h4>Art Director - Staffan Marmenlind</h4>
        <img src="../images/kevin.jpg" alt="Kevin" /><br>
<span>When it comes to marketing, visual design and creative process Staffan is in charge. Everything from social media promotion to million dollar commercial spots goes through this man. Even though his parents left him a huge heritage he still comes to the office once in a while sparkling some advertising gold on the business.
</span>
    </div>

    <div>
        <h4>Webdesigner - Kevin Strimer</h4>
        <img src="../images/kevin.jpg" alt="Kevin" /><br>
<span>Kevin is the Webmaster at Invictus, his creative abilities combined with his programming skills makes him the best in his class. Kevin always comes up with a solution and no problem is too big for this man. His extraordinary productivity in the office leaves him a lot of time to play Fifa during business hours, and can be difficult to reach if you call during a exciting game of playstation.
</span>
    </div>

    <div>
        <h4>Intern - David Yu</h4>
        <img src="../images/kevin.jpg" alt="Kevin" /><br>
<span>Our intern here at Invictus is David, a motivated young boy trying to make it in the big world. His programming skills is questionable but he always tries his best. A interesting man with a lot on his mind. David distinguish himself by carrying around a lot of computer keyboards and is known for always having freshly cut hair.
</span>
    </div>
    
    </article>
</section>';
}
?>