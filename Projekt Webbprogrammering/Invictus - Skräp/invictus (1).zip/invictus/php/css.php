<?php
function css_story(){
return
    '<link rel="stylesheet" href="../css/our_story.css"/>'; 
}

?>