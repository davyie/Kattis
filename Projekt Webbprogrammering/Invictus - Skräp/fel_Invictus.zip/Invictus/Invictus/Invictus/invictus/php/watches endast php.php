<?php
include_once "header_footer_mall.php";

echo watches_header();
echo section_watches();
echo mall_footer();
?>