<?php
	
include_once "db_connect.php";

	
	?>
<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<title>insert product</title>	
        <link rel="stylesheet" href="../css/sign_up.css"/>
        <link rel="stylesheet" href="../css/header.css"/>
        <link rel="stylesheet" href="../css/footer.css"/>
	</head>
	<body>
	<header>
    
<div>
     <a href="index.php" ><img src="../images/logo.png"/></a>
    </div>
    
    <nav id="navigation" class="global-navigation" role="navigation">
    <ul class="global">
        <li class="huvudmeny"><a href="watches.php">Watches</a>
        <ul class="drop">
        <li class="submeny"><a href="classic.php">Classic Watches</a></li>
        <li class="submeny"><a href="exclusive.php">Exclusive Watches</a</li>
        <li class="submeny"><a href="sport.php">Sport Watches</a>           </li>
        </ul>
        </li>
    <li class="huvudmeny"><a href="our_story.php">Our story</a>         </li>
    <li class="huvudmeny"><a href="social_media.php">Social media</a></li>
    <li class="huvudmeny"><a href="../html/contact_us.html">Contact us</a>       </li>
     <li class="huvudmeny"><a href="shopping_cart.php">My Account</a>
         <ul class="drop2">
            <li class="submeny2"><a href="log_in.php">Login</a></li>
            <li class="submeny2"><a href="sign_up.php">Signup</a</li>
            <li class="submeny2"><a href="kassa.php">Shopping Cart</a> </li>
        </ul>
            </li>
	</ul>
</nav>
        
</header>
	<?php
	


	// Lägger till en tillbakaknapp tex	
	echo  "<div class=adminheader><h2>Lägg till produkt</h2><a href='index.php'>Förstasidan</a></div>";

	// vad som händer om "spara" är iklickad
	if(isset($_POST['spara'])){
	
		// Hämtar värderna från formuläret
		
		
		$namn = $_POST['namn'];
		$Type = $_POST['Type'];
		$beskrivning = $_POST['beskrivning'];	
		$price = $_POST['price'];			
		$Produktnummer = $_POST['Produktnummer'];
		$Produktbild = $_POST['Produktbild'];	
		$Lagersaldo = $_POST['Lagersaldo'];	
		$size = $_POST['size'];
		$width = $_POST['width'];
	
		// SQL-fråga (INSERT) 
		$sql = "INSERT INTO produkt (namn,Type,beskrivning,price,Produktnummer,Produktbild,Lagersaldo,size,width) 
		VALUES ('$namn','$Type','$beskrivning','$price','$Produktnummer','$Produktbild','$Lagersaldo','$size','$width')";
	
		// Kör frågan
		if($mysqli = connect_db()) {
 	
		$mysqli->query($sql);
		print_r($mysqli->error);
		}
		
		
	
		// Visar att personen är inlagd och ger en länk till startsidan
		echo "Produkten är nu inlagd i databasen<br />";
		echo "<a href='index.php'>Tillbaka till listningssidan</a>";
	}

	// Vad som händer om användare INTE klickar på spara-knapp
	else{

		
		
		?>
		
		<!-- Ett formulär med samtliga kolumner på den aktuella raden -->
		<!--  PersonId skickas med i querystring, detta görs i formulärets action-attribut -->
		<!-- I varje cell skrivs en kolumn ut, detta med hjälp av variabeln $myRow (arrayen som resultatet av SQL-frågan sparats i) -->
		
		<form action="insert_product.php" method="post">
			<table cellpadding="3" cellspacing="0" border="1">
				

				<tr><td>Produktnamn</td><td><input type="text" name="namn"  /></td></tr>
				<tr><td>Type</td><td><input type="text" name="Type"  /></td></tr>
				<tr><td>Beskrivning</td><td><input type="text" name="beskrivning"  /></td></tr>
				<tr><td>Price</td><td><input type="text" name="price"  /></td></tr>				
				<tr><td>Produktnummer</td><td><input type="text" name="Produktnummer"  /></td></tr>
				<tr><td>Produktbild</td><td><input type="text" name="Produktbild"  /></td></tr>
				<tr><td>Lagersaldo</td><td><input type="text" name="Lagersaldo"  /></td></tr>
				<tr><td>Size</td><td><input type="text" name="size"  /></td></tr>
				<tr><td>Width</td><td><input type="text" name="width"  /></td></tr>
				<tr><td colspan="2"><input type="submit" name="spara" value="Spara" />
			</table>
		</form>
		<?php
	}
	?>
<footer>
    <div id="adress">
        Contact us
    <br>
    <br>
        Sturegatan 4
    <br>
        114 35 Stockholm
    <br>
        Sweden
    <br>
        <a href="mailto:invictuswatches@gmail.com">invictuswatches@gmail.com</a>
    <br>
        <a href="tel:+46 589-861-00">+46 589-861-00</a>
    </div>
    
    <div id="social">
        Social media
    <br>
    <br>
        <a href="https://www.instagram.com/invictuswatches/">
        <img src="../images/instagram.png" alt="instagram"/>
        </a>
        <a href="https://twitter.com/InvictusWatches">
        <img src="../images/twitter.png" alt="twitter" />     
        </a>
        <a href="https://www.facebook.com/invictuswatches/?notif_t=fbpage_fan_invite">
        <img src="../images/facebook.png" alt="facebook" />     
        </a>
    </div>
    
    <div id="account">
        Account
    <br>
    <br>
        <a href="log_in.php">Log in</a>
    <br>
        <a href="sign_up.php">Sign up</a>
    </div>
    
    <div id="payment">
        Payment methods
    <br>
    <br>
        <img src="../images/mastercard.png" alt="mc" />     
        <img src="../images/americanexpress.png" alt="amex" />     
        <img src="../images/visa.png" alt="visa" />     
        </div>
        </footer>
	</body>
</html>